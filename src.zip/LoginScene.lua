
local LoginScene = class("LoginScene",cc.Layer)
function LoginScene:ctor()   
    self:onCreate(); --�������� 
end
function LoginScene:onCreate()
    
    local progressLable = cc.Label:createWithSystemFont("�����ǵ�¼","",30)
    progressLable:setAnchorPoint(cc.p(0.5, 0.5))
    progressLable:setPosition(cc.p(500,500)):addTo(self); 
    
end 
 
return LoginScene
