
local MainScene = class("MainScene", cc.Layer)


function MainScene:ctor()   
    self:onCreate(); --调用子类 
end
function MainScene:onCreate()
    --测试json解析
    local JSON = require("json")   --全局json解析模块 
    local status,msg = pcall(function() return JSON.decode("{'MsgType':4,,'SubMsgType':1,'Msg':'[1,2]'}")end);
    dump(status);
    if status then
        dump(msg);
    else
        dump("解析error")
    end
    --
    local progressLable = cc.Label:createWithSystemFont("初始化完�?,"",30)
    progressLable:setAnchorPoint(cc.p(0.5, 0.5))
    progressLable:setPosition(cc.p(500,500)):addTo(self);
    --测试下载
    local assetsManager       = nil
    local pathToSave          = "down33"
    local function onError(errorCode)
         dump("onError",errorCode);
        if errorCode == cc.ASSETSMANAGER_NO_NEW_VERSION then
            progressLable:setString("no new version")
        elseif errorCode == cc.ASSETSMANAGER_NETWORK then
            progressLable:setString("network error")
        end
    end

    local function onProgress( percent )
         dump("onProgress");
        local progress = string.format("downloading %d%%",percent)
        progressLable:setString(progress)
    end

    local function onSuccess()
        dump("onSuccess");
        progressLable:setString("downloading ok")
        self:gotoLogin();
    end
    local function getAssetsManager()
        if nil == assetsManager then
            dump("assetsManager");
            assetsManager = cc.AssetsManager:new("https://raw.github.com/samuele3hu/AssetsManagerTest/master/package.zip",
                                           "https://raw.githubusercontent.com/kodking2025/cocos2dx-lua/master/version",
                                           pathToSave)
            assetsManager:retain()
            assetsManager:setDelegate(onError, cc.ASSETSMANAGER_PROTOCOL_ERROR )
            assetsManager:setDelegate(onProgress, cc.ASSETSMANAGER_PROTOCOL_PROGRESS)
            assetsManager:setDelegate(onSuccess, cc.ASSETSMANAGER_PROTOCOL_SUCCESS )
            assetsManager:setConnectionTimeout(3)
        end

        return assetsManager
    end
    self:runAction(cc.Sequence:create(cc.DelayTime:create(1),cc.CallFunc:create(function()
                    --getAssetsManager():deleteVersion();
        local ver = getAssetsManager():getVersion();
        local bool = getAssetsManager():checkUpdate()
        if bool then 
            getAssetsManager():update()
        end
        dump(ver);
        dump(bool);
    end)));
    
end 

function MainScene:gotoLogin() 
    self:runAction(cc.Sequence:create(cc.DelayTime:create(1),cc.CallFunc:create(function()
            local view = require("LoginScene"):create();
            showWithScene(view);     
    end)));
end 
return MainScene
