
cc.FileUtils:getInstance():setPopupNotify(false)

require "config"
require "cocos.init"
function showWithScene(view)
    view:setVisible(true)
    local scene = display.newScene(view.name_)
    scene:addChild(view)
    display.runScene(scene)
end

local function main()
	dump("main################是")
   	local view = require("MainScene").new();
    showWithScene(view);
end

local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
    print(msg)
end
