
local LoginScene = class("LoginScene",cc.Layer)
function LoginScene:ctor()   
    self:onCreate(); --调用子类 
end
function LoginScene:onCreate()
    
    local progressLable = cc.Label:createWithSystemFont("这里是登录5555","",30)
    progressLable:setAnchorPoint(cc.p(0.5, 0.5))
    progressLable:setPosition(cc.p(500,500)):addTo(self); 
    
end 
 
return LoginScene
